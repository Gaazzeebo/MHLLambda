// index.mjs
import axios from 'axios';

// Optional local fallback data if the v1 API call fails
const fallbackProducts = [
  {
    catalogid: 999,
    name: 'Fallback Product v1',
    price: 9.99,
    thumbnailurl: '/assets/logo-placeholder.png',
    mainimagefile: '/assets/logo-placeholder.png',
    description: 'Returned if the 3dcart v1 API call fails',
    stock: 99,
    featured: false,
    categoryid: 'shift4shop',
  },
];

export const handler = async (event) => {
  console.log('===> Event received:', JSON.stringify(event));

  // 1) Basic CORS
  const origin = event.headers?.origin || '*';
  const corsHeaders = {
    'Access-Control-Allow-Origin': origin,
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET,OPTIONS',
    'Content-Type': 'application/json',
  };

  // CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({ message: 'CORS preflight successful' }),
    };
  }

  // 2) Environment variables (or hard-code if needed)
  // Usually, older 3dcart docs say to use `https://apirest.3dcart.com` if the store's custom domain doesn't serve /3dCartWebAPI.
  // Then we do /3dCartWebAPI/v1/Products for the v1 endpoint.
  const storeUrl = process.env.SHIFT4SHOP_STORE_URL || 'https://apirest.3dcart.com';
  const privateKey = process.env.SHIFT4SHOP_PRIVATE_KEY || '';
  const token = process.env.SHIFT4SHOP_TOKEN || '';

  // 3) Validate credentials
  if (!storeUrl || !privateKey || !token) {
    console.error('===> Missing SHIFT4SHOP_STORE_URL, SHIFT4SHOP_PRIVATE_KEY, or SHIFT4SHOP_TOKEN');
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ error: 'Missing 3dcart v1 API credentials in environment variables' }),
    };
  }

  // 4) Construct the v1 endpoint
  // e.g. https://apirest.3dcart.com/3dCartWebAPI/v1/Products?limit=100
  // Adjust if your store uses a different domain or path.
  const apiUrl = `${storeUrl}/3dCartWebAPI/v1/Products?limit=100`;
  console.log(`===> Attempting to fetch products from: ${apiUrl}`);

  try {
    // 5) Make the request, passing PrivateKey & Token in headers
    const response = await axios.get(apiUrl, {
      headers: {
        PrivateKey: privateKey,
        Token: token,
        Accept: 'application/json',
        'Content-Type': 'application/json',
        // Sometimes also:
        // SecureURL: storeUrl
      },
      timeout: 10000, // 10 seconds
    });

    console.log('===> 3dcart v1 API response status:', response.status);
    console.log('===> 3dcart v1 data length:', response.data?.length);

    // Return the raw product data
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify(response.data),
    };
  } catch (error) {
    console.error('===> 3dcart v1 API fetch error:', error.message);
    if (error.response) {
      console.error('===> Error response data:', error.response.data);
      console.error('===> Error response status:', error.response.status);
    }

    // 6) Fallback if the call fails
    console.log('===> Falling back to local fallbackProducts array...');
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify(fallbackProducts),
    };
  }
};
