import axios from 'axios';

// Optional fallback array if the Shift4Shop API call fails.
// You can safely remove this or replace with your own minimal data.
const fallbackProducts = [
  {
    catalogid: 999,
    name: "Fallback Product",
    price: 19.99,
    thumbnailurl: "/assets/logo-placeholder.png",
    mainimagefile: "/assets/logo-placeholder.png",
    description: "This is a fallback item returned when Shift4Shop API call fails.",
    stock: 99,
    featured: false,
    categoryid: "shift4shop",
  },
];

export const handler = async (event) => {
  console.log('Event received:', JSON.stringify(event));

  // 1) Handle CORS
  const origin = event.headers?.origin || '*';
  const corsHeaders = {
    'Access-Control-Allow-Origin': origin,
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET,OPTIONS',
    'Content-Type': 'application/json',
  };

  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({ message: 'CORS preflight successful' }),
    };
  }

  // 2) SHIFT4SHOP Credentials Inline (Not Recommended for Production)
  //    *Better to store these in AWS Lambda > Configuration > Environment variables*
  const storeUrl = 'https://311n16875921454.s4shops.com';
  const clientId = 'a8bcb33baba8cedc03a788448659ca0e';         // FROM Developer Portal: "Client Id"
  const clientSecret = '37ab4b76efdd4a63c967655b9d616610';      // FROM Developer Portal: "Secret Key"

  // 3) Verify Credentials
  if (!clientId || !clientSecret) {
    console.error('Missing Shift4Shop credentials');
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ error: 'Missing Shift4Shop API credentials' }),
    };
  }

  // 4) Acquire OAuth Token
  const tokenUrl = `${storeUrl}/oauth/token`;
  let accessToken;
  try {
    // Request an OAuth token using client credentials
    const tokenResponse = await axios.post(
      tokenUrl,
      new URLSearchParams({
        grant_type: 'client_credentials',
        client_id: clientId,
        client_secret: clientSecret,
      }).toString(),
      {
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        timeout: 5000,
      }
    );

    accessToken = tokenResponse.data?.access_token;
    if (!accessToken) {
      throw new Error('No access_token in OAuth response');
    }
    console.log('OAuth token obtained:', accessToken);
  } catch (tokenError) {
    console.error('OAuth token error:', tokenError.message);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ error: 'Failed to authenticate with Shift4Shop API' }),
    };
  }

  // 5) Call the Shift4Shop Products API
  const apiUrl = `${storeUrl}/api/v1/Products`;
  try {
    const response = await axios.get(apiUrl, {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      params: { limit: 50 },
      timeout: 10000,
    });

    console.log('Shift4Shop API response status:', response.status);

    // Map raw product data to a simpler format
    const mappedProducts = response.data.map((product) => ({
      catalogid: product.CatalogID ?? product.catalogid ?? product.id,
      name: product.Name ?? product.name,
      price: parseFloat(product.Price ?? product.price) || 0,
      listprice: product.ListPrice ? parseFloat(product.ListPrice) : undefined,
      thumbnailurl: 
        product.ThumbnailURL ||
        product.thumbnail ||
        product.MainImage ||
        '/assets/logo-placeholder.png',
      mainimagefile:
        product.MainImage ||
        product.mainimagefile ||
        '/assets/logo-placeholder.png',
      description: product.Description || '',
      stock: parseInt(product.Stock ?? product.stock, 10) || 0,
      featured: product.Featured || false,
      categoryid: 
        product.CategoryID ?? product.categoryid ?? 'shift4shop',
    }));

    // Return success with your mapped products
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify(mappedProducts),
    };

  } catch (apiError) {
    console.error('Shift4Shop API fetch error:', apiError.message);
    if (apiError.response) {
      console.error('Error response data:', apiError.response.data);
    }

    // Return fallback data if the Shift4Shop call fails
    console.log('Falling back to static/fallback products');
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify(fallbackProducts),
    };
  }
};
