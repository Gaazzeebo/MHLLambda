import axios from 'axios';

// Fallback data in case the API call fails
const fallbackProducts = [
  {
    catalogid: 999,
    name: 'Fallback Product v1',
    price: 9.99,
    thumbnailurl: '/assets/logo-placeholder.png',
    mainimagefile: '/assets/logo-placeholder.png',
    description: 'Returned if the 3dcart v1 API call fails.',
    stock: 99,
    featured: false,
    categoryid: 'shift4shop',
  },
];

export const handler = async (event) => {
  console.log('===> Event received:', JSON.stringify(event));

  // 1. CORS Handling
  const origin = event.headers?.origin || '*';
  const corsHeaders = {
    'Access-Control-Allow-Origin': origin,
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET,OPTIONS',
    'Content-Type': 'application/json',
  };

  // Handle CORS preflight request
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({ message: 'CORS preflight successful' }),
    };
  }

  // 2. Read credentials from environment variables
  const storeUrl = process.env.SHIFT4SHOP_STORE_URL || 'https://apirest.3dcart.com';
  const privateKey = process.env.SHIFT4SHOP_PRIVATE_KEY || '37ab4b76efdd4a63c967655b9d616610';
  const token = process.env.SHIFT4SHOP_TOKEN || '910d514950707115391650f15e36aa56';

  // 3. Validate credentials
  if (!storeUrl || !privateKey || !token) {
    console.error('Missing required environment variables for 3dcart API');
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({
        error: 'Missing SHIFT4SHOP_STORE_URL, SHIFT4SHOP_PRIVATE_KEY, or SHIFT4SHOP_TOKEN',
      }),
    };
  }

  // 4. Build the v1 endpoint URL with limit=100
  // The final URL should be:
  // https://apirest.3dcart.com/3dCartWebAPI/v1/Products?limit=100
  const apiUrl = `${storeUrl}/3dCartWebAPI/v1/Products?limit=100`;
  console.log(`===> Attempting to fetch products from: ${apiUrl}`);

  try {
    // 5. Make the GET request with proper headers
    const response = await axios.get(apiUrl, {
      headers: {
        PrivateKey: privateKey,
        Token: token,
        Accept: 'application/json',
        'Content-Type': 'application/json',
        // If needed, you can add: SecureURL: storeUrl,
      },
      timeout: 10000, // 10 seconds timeout
    });

    console.log('===> 3dcart v1 API response status:', response.status);
    console.log('===> 3dcart v1 data length:', response.data?.length);

    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify(response.data),
    };
  } catch (error) {
    console.error('===> 3dcart v1 API fetch error:', error.message);
    if (error.response) {
      console.error('===> Error response data:', error.response.data);
      console.error('===> Error response status:', error.response.status);
    }

    console.log('===> Falling back to local fallbackProducts array...');
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify(fallbackProducts),
    };
  }
};
