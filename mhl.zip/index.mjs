// index.mjs - Complete AWS Lambda Function with CORS Headers (ES Module Version)

// Import axios for HTTP requests
import axios from 'axios';

export const handler = async (event) => {
    console.log('Event received:', JSON.stringify(event));
    
    // Extract origin for CORS headers
    const origin = event.headers && event.headers.origin ? event.headers.origin : '*';
    console.log('Request origin:', origin);
    
    // Define CORS headers
    const corsHeaders = {
        'Access-Control-Allow-Origin': origin,
        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
        'Access-Control-Allow-Methods': 'GET,OPTIONS',
        'Content-Type': 'application/json'
    };
    
    // Handle preflight OPTIONS request
    if (event.httpMethod === 'OPTIONS') {
        return {
            statusCode: 200,
            headers: corsHeaders,
            body: JSON.stringify({ message: 'CORS preflight successful' })
        };
    }
    
    // Get API token from environment variable
    const apiToken = process.env.SHIFT4SHOP_API_TOKEN || '910d514950707115391650f15e36aa56';
    
    // Log credentials status
    console.log('API Token Status:', apiToken ? 'Present' : 'Missing');
    
    // Try the Shift4Shop API URL (corrected to match your store)
    const apiUrls = [
        'https://311n16875921454.api.shift4shop.com/v1/products', // Correct primary URL
        'https://apirest.3dcart.com/3dCartWebAPI/v1/products',   // Backup (if needed)
        'https://api.shift4shop.com/v1/products',                 // Generic backup
        'https://api.3dcart.com/v1/products'                      // Legacy backup
    ];
    
    // Prepare headers with Bearer token
    const headers = {
        'Authorization': `Bearer ${apiToken}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    };
    
    let lastError = null;
    
    // Try each URL
    for (const url of apiUrls) {
        try {
            console.log(`Attempting to fetch from: ${url}`);
            
            const response = await axios.get(url, {
                params: { limit: 50 }, // Adjust limit as needed
                headers: headers,
                timeout: 10000 // 10-second timeout
            });
            
            console.log(`Success with URL: ${url}`);
            console.log('Response status:', response.status);
            console.log('Response data length:', JSON.stringify(response.data).length);
            
            // Map the API response to match Shift4ShopProduct interface
            const mappedProducts = response.data.map((product) => ({
                catalogid: product.id || product.catalogid, // Use 'id' or 'catalogid' based on API response
                name: product.name,
                price: parseFloat(product.price) || 0,
                listprice: product.list_price ? parseFloat(product.list_price) : undefined, // Adjust based on API response
                thumbnailurl: product.thumbnail || product.thumbnailurl || product.image1 || '/assets/logo-placeholder.png',
                mainimagefile: product.image1 || product.thumbnail || '/assets/logo-placeholder.png',
                description: product.description || '',
                stock: parseInt(product.stock, 10) || 0,
                featured: product.featured || false,
                categoryid: product.categories || product.categoryid || 'shift4shop'
            }));
            
            // Return successful response with CORS headers
            return {
                statusCode: 200,
                headers: corsHeaders,
                body: JSON.stringify(mappedProducts)
            };
        } catch (error) {
            console.log(`Error with URL ${url}:`, error.message);
            if (error.response) {
                console.log('Error response status:', error.response.status);
                console.log('Error response data:', JSON.stringify(error.response.data).substring(0, 200) + '...');
            }
            lastError = error;
            // Continue to next URL
        }
    }
    
    // If all URLs fail, return the provided product data as static fallback (temporary)
    console.log('All URLs failed, returning static product data');
    
    const staticProducts = [
        { catalogid: 12, id: "ADMN-NOV15", name: "GENERAL ADMISSION - NOV 15 - 7:30 PM Breckenridge Vipers vs Park City SilverKings", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 22, categories: "VIPERS HOME GAME TICKETS (AVAILABLE NOW!!)/NOV 15 - 7:30 PM (Breckenridge Vipers vs Park City SilverKings)", description: "", keywords: "", stock: 833 },
        { catalogid: 14, id: "ALLACCESS-NOV15", name: "WHISKEY STAR SKYBOX - NOV 15 (Breckenridge Vipers vs Park City SilverKings)", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 44, categories: "WHISKEY STAR SKYBOX", description: "", keywords: "", stock: 12 },
        { catalogid: 18, id: "ADMN-NOV16", name: "GENERAL ADMISSION - NOV 16 - 7:30 PM Breckenridge Vipers vs Park City SilverKings", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 22, categories: "VIPERS HOME GAME TICKETS (AVAILABLE NOW!!)/NOV 16 - 7:30 PM (Breckenridge Vipers vs Park City SilverKings)", description: "", keywords: "", stock: 972 },
        { catalogid: 19, id: "ADMN-NOV22", name: "GENERAL ADMISSION - NOV 22 - 7:30 PM Breckenridge Vipers vs Mansfield", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 22, categories: "VIPERS HOME GAME TICKETS (AVAILABLE NOW!!)/NOV 22 - 7:30 PM (Breckenridge Vipers vs Mansfield)", description: "", keywords: "", stock: 921 },
        { catalogid: 21, id: "ADMN-NOV23", name: "GENERAL ADMISSION - NOV 23 - 7:30 PM Breckenridge Vipers vs Mansfield", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 22, categories: "VIPERS HOME GAME TICKETS (AVAILABLE NOW!!)/NOV 23 - 7:30 PM (Breckenridge Vipers vs Mansfield)", description: "", keywords: "", stock: 918 },
        { catalogid: 22, id: "ADMN-DEC6", name: "GENERAL ADMISSION - DEC 6 - 7:30 PM Breckenridge Vipers vs Las Vegas", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 22, categories: "VIPERS HOME GAME TICKETS (AVAILABLE NOW!!)/DEC 6 - 7:30 PM (Breckenridge Vipers vs Las Vegas)", description: "", keywords: "", stock: 910 },
        { catalogid: 23, id: "ADMN-DEC7", name: "GENERAL ADMISSION - DEC 7 - 7:30 PM Breckenridge Vipers vs Las Vegas", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 22, categories: "VIPERS HOME GAME TICKETS (AVAILABLE NOW!!)/DEC 7 - 7:30 PM (Breckenridge Vipers vs Las Vegas)", description: "", keywords: "", stock: 903 },
        { catalogid: 24, id: "ADMN-JAN10", name: "GENERAL ADMISSION - JAN 10 - 7:30 PM Breckenridge Vipers vs San Diego", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 22, categories: "VIPERS HOME GAME TICKETS (AVAILABLE NOW!!)/JAN 10 - 7:30 PM (Breckenridge Vipers vs San Diego)", description: "", keywords: "", stock: 785 },
        { catalogid: 25, id: "ADMN-JAN11", name: "GENERAL ADMISSION - JAN 11 - 7:30 PM Breckenridge Vipers vs San Diego", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 22, categories: "VIPERS HOME GAME TICKETS (AVAILABLE NOW!!)/JAN 11 - 7:30 PM (Breckenridge Vipers vs San Diego)", description: "", keywords: "", stock: 857 },
        { catalogid: 26, id: "ADMN-FEB21", name: "GENERAL ADMISSION - FEB 21 - 7:30 PM Breckenridge Vipers vs Steamboat Vigilantes", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 22, categories: "VIPERS HOME GAME TICKETS (AVAILABLE NOW!!)/FEB 21 - 7:30 PM (Breckenridge Vipers vs Steamboat Vigilantes)", description: "", keywords: "", stock: 861 },
        { catalogid: 29, id: "ADMN-FEB28", name: "GENERAL ADMISSION - FEB 28 - 7:30 PM Breckenridge Vipers vs Vail", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 22, categories: "VIPERS HOME GAME TICKETS (AVAILABLE NOW!!)/FEB 28 - 7:30 PM (Breckenridge Vipers vs Vail)", description: "", keywords: "", stock: 0 },
        { catalogid: 30, id: "ADMN-MAR7", name: "GENERAL ADMISSION - MAR 7 - 7:30 PM Breckenridge Vipers vs Santa Rosa", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 22, categories: "VIPERS HOME GAME TICKETS (AVAILABLE NOW!!)/MAR 7 - 7:30 PM (Breckenridge Vipers vs Santa Rosa)", description: "", keywords: "", stock: 997 },
        { catalogid: 31, id: "ADMN-MAR8", name: "GENERAL ADMISSION - MAR 8 - 7:30 PM Breckenridge Vipers vs Santa Rosa", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 22, categories: "VIPERS HOME GAME TICKETS (AVAILABLE NOW!!)/MAR 8 - 7:30 PM (Breckenridge Vipers vs Santa Rosa)", description: "", keywords: "", stock: 998 },
        { catalogid: 32, id: "ALLACCESS-NOV16", name: "WHISKEY STAR SKYBOX - NOV 16 VIPERS VS PARK CITY", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 44, categories: "WHISKEY STAR SKYBOX", description: "", keywords: "", stock: 42 },
        { catalogid: 33, id: "ALLACCESS-NOV22", name: "WHISKEY STAR SKYBOX - NOV 22 VIPERS VS MANSFIELD", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 44, categories: "WHISKEY STAR SKYBOX", description: "", keywords: "", stock: 44 },
        { catalogid: 34, id: "ALLACCESS-NOV23", name: "WHISKEY STAR SKYBOX - NOV 23 VIPERS VS MANSFIELD", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 44, categories: "WHISKEY STAR SKYBOX", description: "", keywords: "", stock: 49 },
        { catalogid: 35, id: "ALLACCESS-DEC6", name: "WHISKEY STAR SKYBOX - DEC 6 VIPERS VS LAS VEGAS", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 44, categories: "WHISKEY STAR SKYBOX", description: "", keywords: "", stock: 49 },
        { catalogid: 36, id: "ALLACCESS-DEC7", name: "WHISKEY STAR SKYBOX - DEC 7 VIPERS VS LAS VEGAS", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 44, categories: "WHISKEY STAR SKYBOX", description: "", keywords: "", stock: 49 },
        { catalogid: 37, id: "ALLACCESS-JAN10", name: "WHISKEY STAR SKYBOX - JAN 10 VIPERS VS SAN DIEGO", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 44, categories: "WHISKEY STAR SKYBOX", description: "", keywords: "", stock: 15 },
        { catalogid: 38, id: "ALLACCESS-JAN11", name: "WHISKEY STAR SKYBOX - JAN 11 VIPERS VS SAN DIEGO", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 44, categories: "WHISKEY STAR SKYBOX", description: "", keywords: "", stock: 44 },
        { catalogid: 39, id: "ALLACCESS-FEB21", name: "WHISKEY STAR SKYBOX - FEB 21 VIPERS VS Steamboat Vigilantes", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 44, categories: "WHISKEY STAR SKYBOX", description: "", keywords: "", stock: 42 },
        { catalogid: 40, id: "ALLACCESS-FEB28", name: "WHISKEY STAR SKYBOX - FEB 28 VIPERS VS VAIL", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 44, categories: "WHISKEY STAR SKYBOX", description: "", keywords: "", stock: 0 },
        { catalogid: 41, id: "ALLACCESS-FEB22", name: "WHISKEY STAR SKYBOX - FEB 22 VIPERS VS Steamboat Vigilantes", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 44, categories: "WHISKEY STAR SKYBOX", description: "", keywords: "", stock: 45 },
        { catalogid: 42, id: "ALLACCESS-MAR7", name: "WHISKEY STAR SKYBOX - MAR7 (Breckenridge Vipers vs Santa Rosa)", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 44, categories: "WHISKEY STAR SKYBOX", description: "", keywords: "", stock: 50 },
        { catalogid: 43, id: "ALLACCESS-MAR8", name: "WHISKEY STAR SKYBOX - MAR 8 (Breckenridge Vipers vs Santa Rosa)", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 44, categories: "WHISKEY STAR SKYBOX", description: "", keywords: "", stock: 50 },
        { catalogid: 46, id: "CHILD-NOV15", name: "CHILD ADMISSION - NOV15 Breckenridge Vipers vs Park City SilverKings", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 7, categories: "CHILD TICKETS (12 & UNDER)", description: "", keywords: "", stock: 493 },
        { catalogid: 47, id: "CHILD-NOV16", name: "CHILD ADMISSION - NOV16 Breckenridge Vipers vs Park City SilverKings", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 7, categories: "CHILD TICKETS (12 & UNDER)", description: "", keywords: "", stock: 499 },
        { catalogid: 48, id: "CHILD-NOV 22", name: "CHILD ADMISSION - NOV 22 Breckenridge Vipers vs Mansfield", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 7, categories: "CHILD TICKETS (12 & UNDER)", description: "", keywords: "", stock: 495 },
        { catalogid: 49, id: "CHILD-DEC7", name: "CHILD ADMISSION - DEC7 Breckenridge Vipers vs Las Vegas", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 7, categories: "CHILD TICKETS (12 & UNDER)", description: "", keywords: "", stock: 497 },
        { catalogid: 50, id: "CHILD-JAN10", name: "CHILD ADMISSION - JAN 10 Breckenridge Vipers vs San Diego", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 7, categories: "CHILD TICKETS (12 & UNDER)", description: "", keywords: "", stock: 493 },
        { catalogid: 51, id: "CHILD-DEC6", name: "CHILD ADMISSION - DEC6 Breckenridge Vipers vs Las Vegas", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 7, categories: "CHILD TICKETS (12 & UNDER)", description: "", keywords: "", stock: 500 },
        { catalogid: 52, id: "CHILD-NOV23", name: "CHILD ADMISSION - NOV 23 Breckenridge Vipers vs Mansfield", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 7, categories: "CHILD TICKETS (12 & UNDER)", description: "", keywords: "", stock: 500 },
        { catalogid: 53, id: "CHILD-JAN11", name: "CHILD ADMISSION - JAN 11 Breckenridge Vipers vs San Diego", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 7, categories: "CHILD TICKETS (12 & UNDER)", description: "", keywords: "", stock: 497 },
        { catalogid: 54, id: "CHILD-FEB28", name: "CHILD ADMISSION - FEB 28 Breckenridge Vipers vs Vail", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 7, categories: "CHILD TICKETS (12 & UNDER)", description: "", keywords: "", stock: 0 },
        { catalogid: 55, id: "CHILD-FEB21", name: "CHILD ADMISSION - FEB 21 Breckenridge Vipers vs Steamboat Vigilantes", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 7, categories: "CHILD TICKETS (12 & UNDER)", description: "", keywords: "", stock: 495 },
        { catalogid: 56, id: "CHILD-MAR8", name: "CHILD ADMISSION - MAR 8 Breckenridge Vipers vs Santa Rosa", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 7, categories: "CHILD TICKETS (12 & UNDER)", description: "", keywords: "", stock: 500 },
        { catalogid: 57, id: "CHILD-FEB22", name: "CHILD ADMISSION - FEB 22 Breckenridge Vipers vs Steamboat Vigilantes", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 7, categories: "CHILD TICKETS (12 & UNDER)", description: "", keywords: "", stock: 497 },
        { catalogid: 64, id: "CHILD-MAR7", name: "CHILD ADMISSION - MAR 7 Breckenridge Vipers vs Santa Rosa", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 7, categories: "CHILD TICKETS (12 & UNDER)", description: "", keywords: "", stock: 500 },
        { catalogid: 65, id: "SEASON2024/25", name: "SKYBOX SEASON PASS 2024/25", image1: "assets/images/3.png", thumbnail: "assets/images/thumbnails/3_thumbnail.png", price: 395, categories: "SEASON TICKETS", description: "", keywords: "", stock: 145 },
        { catalogid: 66, id: "SEASON2024/25-ULTIMATE", name: "SKYBOX VIPERS FAN PACKAGE ", image1: "assets/images/alt color 10th anniversary logo (5)84.png", thumbnail: "assets/images/thumbnails/alt color 10th anniversary logo (5)84_thumbnail.png", price: 695, categories: "SEASON TICKETS", description: "2 Season Passes & 1 Game Worn Jersey!  All-Access Passes VIP Whiskey Star Catered SkyBox! ", keywords: "", stock: 28 },
        { catalogid: 67, id: "67", name: "Viper Pit- Season Pass 17 Games ", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 195, categories: "SEASON TICKETS@GENERAL ADMISSION", description: "General Admission to all 17 Viper Home Games.  Enjoy quick entry with your fast pass at games! ", keywords: "", stock: 189 },
        { catalogid: 69, id: "CHILD-MAR14", name: "CHILD ADMISSION - MAR 14 Breckenridge Vipers vs Bozeman", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 7, categories: "CHILD TICKETS (12 & UNDER)", description: "", keywords: "", stock: 500 },
        { catalogid: 70, id: "CHILD-MAR15", name: "CHILD ADMISSION - MAR 15 Breckenridge Vipers vs Bozeman", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 7, categories: "CHILD TICKETS (12 & UNDER)", description: "", keywords: "", stock: 495 },
        { catalogid: 72, id: "CHILD-MAR21", name: "CHILD ADMISSION - MAR 21 Breckenridge Vipers vs LEAFS", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 7, categories: "CHILD TICKETS (12 & UNDER)", description: "", keywords: "", stock: 498 },
        { catalogid: 73, id: "CHILD-MAR22", name: "CHILD ADMISSION - MAR 22 Breckenridge Vipers vs LEAFS", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 7, categories: "CHILD TICKETS (12 & UNDER)", description: "", keywords: "", stock: 500 },
        { catalogid: 74, id: "ADMN-MAR14", name: "GENERAL ADMISSION - MAR 14 - 7:30 PM Breckenridge Vipers vs Bozeman", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 22, categories: "VIPERS HOME GAME TICKETS (AVAILABLE NOW!!)/MAR 14 - 7:30 PM (Breckenridge Vipers vs Bozeman)", description: "", keywords: "", stock: 990 },
        { catalogid: 75, id: "ADMN-MAR15", name: "GENERAL ADMISSION - MAR 15 - 7:30 PM Breckenridge Vipers vs Bozeman ", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 22, categories: "VIPERS HOME GAME TICKETS (AVAILABLE NOW!!)/MAR 15 - 7:30 PM (Breckenridge Vipers vs Bozeman)", description: "", keywords: "", stock: 995 },
        { catalogid: 76, id: "ADMN-MAR21", name: "GENERAL ADMISSION - MAR 21 - 7:30 PM Breckenridge Vipers vs LEAFS", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 22, categories: "VIPERS HOME GAME TICKETS (AVAILABLE NOW!!)/MAR 21 - 7:30 PM (Breckenridge Vipers vs LEAFS)", description: "", keywords: "", stock: 998 },
        { catalogid: 77, id: "ADMN-MAR21-2", name: "GENERAL ADMISSION - MAR 22 - 7:30 PM Breckenridge Vipers vs LEAFS", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 22, categories: "VIPERS HOME GAME TICKETS (AVAILABLE NOW!!)/MAR 22 - 7:30 PM (Breckenridge Vipers vs LEAFS)", description: "", keywords: "", stock: 998 },
        { catalogid: 78, id: "ALLACCESS-MAR14", name: "WHISKEY STAR SKYBOX - MAR 14 Breckenridge Vipers vs Bozeman", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 44, categories: "WHISKEY STAR SKYBOX", description: "", keywords: "", stock: 50 },
        { catalogid: 79, id: "ALLACCESS-MAR15", name: "WHISKEY STAR SKYBOX - MAR 15 Breckenridge Vipers vs Bozeman ", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 44, categories: "WHISKEY STAR SKYBOX", description: "", keywords: "", stock: 41 },
        { catalogid: 80, id: "ALLACCESS-MAR21", name: "WHISKEY STAR SKYBOX - MAR 21 Breckenridge Vipers vs LEAFS", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 44, categories: "WHISKEY STAR SKYBOX", description: "", keywords: "", stock: 50 },
        { catalogid: 81, id: "ALLACCESS-MAR22", name: "WHISKEY STAR SKYBOX - MAR 22 Breckenridge Vipers vs LEAFS", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 44, categories: "WHISKEY STAR SKYBOX", description: "", keywords: "", stock: 20 },
        { catalogid: 82, id: "ADMN-FEB22", name: "GENERAL ADMISSION - FEB 22 - 7:30 PM Breckenridge Vipers vs Steamboat Vigilantes", image1: "assets/images/thumbnails/1_thumbnail.png", thumbnail: "assets/images/thumbnails/1_thumbnail.png", price: 22, categories: "VIPERS HOME GAME TICKETS (AVAILABLE NOW!!)/FEB 22 - 7:30 PM (Breckenridge Vipers vs Steamboat Vigilantes)", description: "", keywords: "", stock: 881 },
        { catalogid: 86, id: "SEASON2024/25-2", name: "SKYBOX SEASON PASS 2024/25 (COPY)", image1: "assets/images/3.png", thumbnail: "assets/images/thumbnails/3_thumbnail.png", price: 395, categories: "SEASON TICKETS", description: "", keywords: "", stock: 143 },
        { catalogid: 89, id: "89", name: "Black Vipers T-Shirt Unisex Adult", image1: "assets/images/IMG_8815.png", thumbnail: "assets/images/thumbnails/IMG_8815_thumbnail.jpg", price: 35, categories: "", description: "", keywords: "", stock: 100 },
        { catalogid: 90, id: "90", name: "Black Vipers T-Shirt Unisex Youth", image1: "assets/images/IMG_8815.png", thumbnail: "assets/images/thumbnails/IMG_8815_thumbnail.jpg", price: 35, categories: "", description: "", keywords: "", stock: 100 },
        { catalogid: 91, id: "91", name: "Grey Vipers T-Shirt Unisex Adult", image1: "", thumbnail: "", price: 35, categories: "", description: "", keywords: "", stock: 100 },
        { catalogid: 92, id: "92", name: "Grey Vipers T-Shirt Unisex Youth", image1: "", thumbnail: "", price: 35, categories: "", description: "", keywords: "", stock: 100 },
        { catalogid: 93, id: "93", name: "Black Vipers Long Sleeve Adult Unisex", image1: "", thumbnail: "", price: 45, categories: "", description: "", keywords: "", stock: 100 },
        { catalogid: 94, id: "94", name: "Grey Vipers Long Sleeve Adult Unisex", image1: "assets/images/76246357246__5CB42042-F72D-402A-895D-A86DEE2BFCDD.jpeg", thumbnail: "assets/images/thumbnails/76246357246__5CB42042-F72D-402A-895D-A86DEE2BFCDD_thumbnail.jpg", price: 45, categories: "", description: "", keywords: "", stock: 100 },
        { catalogid: 95, id: "95", name: "Black Vipers Longsleeve Youth Unisex", image1: "", thumbnail: "", price: 45, categories: "", description: "", keywords: "", stock: 100 },
        { catalogid: 96, id: "96", name: "Grey Vipers Long Sleeve Unisex Youth", image1: "assets/images/76246357246__5CB42042-F72D-402A-895D-A86DEE2BFCDD.jpeg", thumbnail: "assets/images/thumbnails/76246357246__5CB42042-F72D-402A-895D-A86DEE2BFCDD_thumbnail.jpg", price: 45, categories: "", description: "", keywords: "", stock: 100 },
        { catalogid: 97, id: "97", name: "Black Vipers Hoodie Adult Unisex", image1: "assets/images/IMG_1551.jpeg", thumbnail: "assets/images/thumbnails/IMG_1551_thumbnail.jpg", price: 65, categories: "", description: "", keywords: "", stock: 100 },
        { catalogid: 98, id: "98", name: "Grey Vipers Hoodie Unisex Adult", image1: "", thumbnail: "", price: 65, categories: "", description: "", keywords: "", stock: 100 },
        { catalogid: 99, id: "99", name: "Black Vipers Hoodie Unisex Youth", image1: "assets/images/IMG_1551.jpeg", thumbnail: "assets/images/thumbnails/IMG_1551_thumbnail.jpg", price: 65, categories: "", description: "", keywords: "", stock: 100 },
        { catalogid: 100, id: "100", name: "Grey Vipers Hoodie Unisex Youth", image1: "", thumbnail: "", price: 65, categories: "", description: "", keywords: "", stock: 100 }
    ].map(product => ({
        catalogid: product.catalogid,
        name: product.name,
        price: product.price,
        listprice: undefined, // No list price in your data, but you can add if available
        thumbnailurl: product.thumbnail || product.image1 || '/assets/logo-placeholder.png',
        mainimagefile: product.image1 || product.thumbnail || '/assets/logo-placeholder.png',
        description: product.description || '',
        stock: product.stock,
        featured: false, // Set based on your criteria or API response
        categoryid: product.categories || 'shift4shop'
    }));
    
    return {
        statusCode: 200,
        headers: corsHeaders,
        body: JSON.stringify(staticProducts)
    };
};

// Note: You might want to remove or adjust the staticProducts fallback once the API is working reliably.