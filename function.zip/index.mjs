// index.mjs - Complete AWS Lambda Function with CORS Headers (ES Module Version)

// Import axios instead of require
import axios from 'axios';

export const handler = async (event) => {
    console.log('Event received:', JSON.stringify(event));
    
    // Extract origin for CORS headers
    const origin = event.headers && event.headers.origin ? event.headers.origin : '*';
    console.log('Request origin:', origin);
    
    // Define CORS headers
    const corsHeaders = {
        'Access-Control-Allow-Origin': origin,
        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
        'Access-Control-Allow-Methods': 'GET,OPTIONS',
        'Content-Type': 'application/json'
    };
    
    // Handle preflight OPTIONS request
    if (event.httpMethod === 'OPTIONS') {
        return {
            statusCode: 200,
            headers: corsHeaders,
            body: JSON.stringify({ message: 'CORS preflight successful' })
        };
    }
    
    // Get API credentials from environment variables
    const privateKey = process.env.SHIFT4SHOP_PRIVATE_KEY;
    const token = process.env.SHIFT4SHOP_TOKEN;
    const storeId = process.env.SHIFT4SHOP_STORE_ID;
    
    // Log credentials status
    console.log('API Credentials Status:', {
        'privateKey': privateKey ? 'Present' : 'Missing',
        'token': token ? 'Present' : 'Missing',
        'storeId': storeId ? 'Present' : 'Missing'
    });
    
    // Try multiple API URLs until one works
    const apiUrls = [
        'https://311n16875921454.api.s4shops.com/v1/Products',
        'https://apirest.3dcart.com/3dCartWebAPI/v1/Products',
        'https://api.shift4shop.com/v1/Products',
        'https://api.3dcart.com/v1/Products'
    ];
    
    // Prepare headers
    const headers = {
        'PrivateKey': privateKey,
        'Token': token,
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'StoreId': storeId
    };
    
    let lastError = null;
    
    // Try each URL
    for (const url of apiUrls) {
        try {
            console.log(`Attempting to fetch from: ${url}`);
            
            const response = await axios.get(url, {
                params: { limit: 50 },
                headers: headers,
                timeout: 10000 // 10 second timeout
            });
            
            console.log(`Success with URL: ${url}`);
            console.log('Response status:', response.status);
            console.log('Response data length:', JSON.stringify(response.data).length);
            
            // Return successful response with CORS headers
            return {
                statusCode: 200,
                headers: corsHeaders,
                body: JSON.stringify(response.data)
            };
        } catch (error) {
            console.log(`Error with URL ${url}:`, error.message);
            if (error.response) {
                console.log('Error response status:', error.response.status);
                console.log('Error response data:', JSON.stringify(error.response.data).substring(0, 200) + '...');
            }
            lastError = error;
            // Continue to next URL
        }
    }
    
    // If all URLs fail, return mock data
    console.log('All URLs failed, returning mock data');
    
    return {
        statusCode: 200,
        headers: corsHeaders,
        body: JSON.stringify(getMockData())
    };
};

// Mock data function
function getMockData() {
    return [
        {
            catalogid: 1001,
            name: "GENERAL ADMISSION - MAR 15 - 7:30 PM Breckenridge Vipers vs Rocky Mountain Moose",
            price: 25.00,
            thumbnailurl: "/assets/logo-placeholder.png",
            description: "General Admission seating for the game against Rocky Mountain Moose",
            stock: 100,
            featured: true
        },
        {
            catalogid: 1002,
            name: "WHISKEY STAR SKYBOX - MAR 15 - 7:30 PM Breckenridge Vipers vs Rocky Mountain Moose",
            price: 75.00,
            thumbnailurl: "/assets/logo-placeholder.png",
            description: "Premium Whiskey Star Skybox seating with complimentary food and drinks",
            stock: 20,
            featured: false
        },
        {
            catalogid: 1003,
            name: "CHILD ADMISSION - MAR 15 - 7:30 PM Breckenridge Vipers vs Rocky Mountain Moose",
            price: 15.00,
            thumbnailurl: "/assets/logo-placeholder.png",
            description: "Discounted admission for children under 12",
            stock: 50,
            featured: false
        },
        {
            catalogid: 1004,
            name: "SKYBOX SEASON PASS - 2024-2025 Season",
            price: 499.00,
            thumbnailurl: "/assets/logo-placeholder.png",
            description: "Full season access to the Whiskey Star Skybox for all home games",
            stock: 10,
            featured: true
        },
        {
            catalogid: 1005,
            name: "Viper Pit- Season Pass - 2024-2025 Season",
            price: 395.00,
            thumbnailurl: "/assets/logo-placeholder.png",
            description: "Full season access to all home games with reserved seating in the Viper Pit section",
            stock: 25,
            featured: true
        },
        {
            catalogid: 1006,
            name: "GENERAL ADMISSION - MAR 22 - 7:30 PM Breckenridge Vipers vs Boulder Bison",
            price: 25.00,
            thumbnailurl: "/assets/logo-placeholder.png",
            description: "General Admission seating for the game against Boulder Bison",
            stock: 0, // Sold out
            featured: false
        },
        {
            catalogid: 1007,
            name: "Vipers Home Jersey",
            price: 79.99,
            thumbnailurl: "/assets/logo-placeholder.png",
            description: "Official game jersey with moisture-wicking technology and embroidered team logo.",
            stock: 45,
            featured: true,
            categoryid: "apparel"
        },
        {
            catalogid: 1008,
            name: "Vipers Snapback Hat",
            price: 29.99,
            thumbnailurl: "/assets/logo-placeholder.png",
            description: "Adjustable snapback with embroidered team logo and contrast stitching.",
            stock: 55,
            featured: false,
            categoryid: "headwear"
        },
        {
            catalogid: 1009,
            name: "Vipers Premium Hoodie",
            price: 59.99,
            listprice: 74.99,
            thumbnailurl: "/assets/logo-placeholder.png",
            description: "Premium cotton blend hoodie with front kangaroo pocket and team graphics.",
            stock: 30,
            featured: true,
            categoryid: "apparel"
        }
    ];
}