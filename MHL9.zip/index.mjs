// index.mjs
import axios from 'axios';

// Optional local data if the 3dcart v1 API call fails
const fallbackProducts = [
  {
    catalogid: 999,
    name: 'Fallback Product v1',
    price: 9.99,
    thumbnailurl: '/assets/logo-placeholder.png',
    mainimagefile: '/assets/logo-placeholder.png',
    description: 'Returned if the 3dcart v1 API call fails.',
    stock: 99,
    featured: false,
    categoryid: 'shift4shop',
  },
];

export const handler = async (event) => {
  console.log('===> Event received:', JSON.stringify(event));

  // 1) Basic CORS
  const origin = event.headers?.origin || '*';
  const corsHeaders = {
    'Access-Control-Allow-Origin': origin,
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET,OPTIONS',
    'Content-Type': 'application/json',
  };

  // Handle CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({ message: 'CORS preflight successful' }),
    };
  }

  // 2) Environment variables
  // By default, we assume https://apirest.3dcart.com for the older 3dcart v1 API
  // If your store uses a different domain, set SHIFT4SHOP_STORE_URL to that.
  const storeUrl = process.env.SHIFT4SHOP_STORE_URL || 'https://apirest.3dcart.com';
  const privateKey = process.env.SHIFT4SHOP_PRIVATE_KEY || '';
  const token = process.env.SHIFT4SHOP_TOKEN || '';

  // 3) Validate credentials
  if (!storeUrl) {
    console.error('===> Missing SHIFT4SHOP_STORE_URL');
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ error: 'Missing SHIFT4SHOP_STORE_URL environment variable' }),
    };
  }
  if (!privateKey) {
    console.error('===> Missing SHIFT4SHOP_PRIVATE_KEY');
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ error: 'Missing SHIFT4SHOP_PRIVATE_KEY environment variable' }),
    };
  }
  if (!token) {
    console.error('===> Missing SHIFT4SHOP_TOKEN');
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ error: 'Missing SHIFT4SHOP_TOKEN environment variable' }),
    };
  }

  // 4) Build the v1 endpoint
  // e.g. https://apirest.3dcart.com/3dCartWebAPI/v1/Products?limit=100
  // Use your domain if you know it's correct (and actually hosts the v1 API).
  const apiUrl = `${storeUrl}/3dCartWebAPI/v1/Products?limit=100`;

  console.log(`===> Attempting to fetch products from: ${apiUrl}`);

  try {
    // 5) Make the request with PrivateKey & Token in headers
    const response = await axios.get(apiUrl, {
      headers: {
        PrivateKey: privateKey,
        Token: token,
        Accept: 'application/json',
        'Content-Type': 'application/json',
        // Some older stores may need:
        // SecureURL: storeUrl
      },
      timeout: 10000, // 10 seconds
    });

    console.log('===> 3dcart v1 API response status:', response.status);
    console.log('===> 3dcart v1 data length:', response.data?.length);

    // Return product data
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify(response.data),
    };
  } catch (error) {
    console.error('===> 3dcart v1 API fetch error:', error.message);
    if (error.response) {
      console.error('===> Error response data:', error.response.data);
      console.error('===> Error response status:', error.response.status);
    }

    // 6) Fallback if the call fails
    console.log('===> Falling back to fallbackProducts array...');
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify(fallbackProducts),
    };
  }
};
