import axios from 'axios';

export const handler = async (event) => {
  console.log('Event received:', JSON.stringify(event));

  // 1. Handle CORS
  const origin = event.headers?.origin || '*';
  const corsHeaders = {
    'Access-Control-Allow-Origin': origin,
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET,OPTIONS',
    'Content-Type': 'application/json',
  };

  // If it's an OPTIONS request, return a 200 for CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({ message: 'CORS preflight successful' }),
    };
  }

  // 2. Environment variables (or hard-coded if needed; environment is recommended)
  //    SHIFT4SHOP_STORE_URL might be e.g. "https://311n16875921454.s4shops.com"
  //    SHIFT4SHOP_PRIVATE_KEY is "37ab4b76efdd4a63c967655b9d616610" from your Developer Portal
  //    SHIFT4SHOP_TOKEN is "910d514950707115391650f15e36aa56" from your Developer Portal

  const storeUrl = process.env.SHIFT4SHOP_STORE_URL || 'https://311n16875921454.s4shops.com';
  const privateKey = process.env.SHIFT4SHOP_PRIVATE_KEY || '37ab4b76efdd4a63c967655b9d616610';
  const token = process.env.SHIFT4SHOP_TOKEN || '910d514950707115391650f15e36aa56';

  // 3. Validate credentials
  if (!storeUrl || !privateKey || !token) {
    console.error('Missing 3dcart (Shift4Shop) v2 API credentials');
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ error: 'Missing environment variables for storeUrl, privateKey, or token' }),
    };
  }

  // 4. Construct the v2 API URL, setting limit=100
  // Example: https://311n16875921454.s4shops.com/3dCartWebAPI/v2/Products?limit=100
  const productsUrl = `${storeUrl}/3dCartWebAPI/v2/Products?limit=100`;

  try {
    // 5. Perform the request with PrivateKey & Token
    const response = await axios.get(productsUrl, {
      headers: {
        PrivateKey: privateKey,
        Token: token,
        // Some stores also need:
        // SecureURL: storeUrl,
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      timeout: 10000,
    });

    console.log('Shift4Shop v2 API status:', response.status);

    // Return the products directly
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify(response.data), // or map them if you like
    };

  } catch (error) {
    console.error('Shift4Shop v2 API fetch error:', error.message);
    if (error.response) {
      console.error('Error response data:', error.response.data);
    }

    // Return an error message
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ error: error.message || 'API request failed' }),
    };
  }
};
