import axios from 'axios';

export const handler = async (event) => {
  console.log('Event received:', JSON.stringify(event));

  // Basic CORS
  const origin = event.headers?.origin || '*';
  const corsHeaders = {
    'Access-Control-Allow-Origin': origin,
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET,OPTIONS',
    'Content-Type': 'application/json',
  };

  // Handle CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({ message: 'CORS preflight successful' }),
    };
  }

  // Potentially use capital 'N' here:
  const storeUrl = 'https://311N16875921454.s4shops.com';

  // Private Key & Token from your developer portal:
  const privateKey = '37ab4b76efdd4a63c967655b9d616610';
  const token = '910d514950707115391650f15e36aa56';

  try {
    // Use the v2 endpoint with limit=100
    const apiUrl = `${storeUrl}/3dCartWebAPI/v2/Products?limit=100`;

    const response = await axios.get(apiUrl, {
      headers: {
        PrivateKey: privateKey,
        Token: token,
        // Some stores also need: SecureURL: storeUrl,
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      timeout: 10000,
    });

    console.log('Shift4Shop v2 API status:', response.status);

    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify(response.data),
    };

  } catch (error) {
    console.error('Shift4Shop v2 API fetch error:', error.message);
    if (error.response) {
      console.error('Error response data:', error.response.data);
    }
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ error: error.message }),
    };
  }
};
