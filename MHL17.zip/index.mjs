import axios from 'axios';

// Fallback data if the API call fails
const fallbackProducts = [
  {
    catalogid: 999,
    name: 'Fallback Product',
    price: 9.99,
    thumbnailurl: '/assets/logo-placeholder.png',
    mainimagefile: '/assets/logo-placeholder.png',
    description: 'Returned if the Shift4Shop API call fails.',
    stock: 99,
    featured: false,
    categoryid: 'shift4shop',
  },
];

// Default order statuses if API call fails
const fallbackOrderStatuses = [
  { OrderStatusID: 1, Sorting: 1, StatusDefinition: "New", StatusText: "New", Visible: true },
  { OrderStatusID: 2, Sorting: 2, StatusDefinition: "Processing", StatusText: "Processing", Visible: true },
  { OrderStatusID: 3, Sorting: 3, StatusDefinition: "Shipped", StatusText: "Shipped", Visible: true },
  { OrderStatusID: 4, Sorting: 4, StatusDefinition: "Completed", StatusText: "Completed", Visible: true },
];

// List of allowed origins - add your domains here
const allowedOrigins = [
  'https://main.d3oft2ruceh6kv.amplifyapp.com',
  'https://main.d3oft2ruceh6kv.amplifyapp.com/',
  'http://localhost:3000',
  // Add any other domains you need to support
];

export const handler = async (event) => {
  console.log('===> Event received:', JSON.stringify(event));

  // 1. Improved CORS Handling
  // Get the origin from the request headers
  const requestOrigin = event.headers?.origin || '';
  
  // Check if the origin is in our allowed list - remove trailing slash for comparison
  const normalizedRequestOrigin = requestOrigin.endsWith('/') 
    ? requestOrigin.slice(0, -1) 
    : requestOrigin;
  
  const normalizedAllowedOrigins = allowedOrigins.map(origin => 
    origin.endsWith('/') ? origin.slice(0, -1) : origin
  );
  
  // Set the Access-Control-Allow-Origin header to the request origin if it's allowed,
  // otherwise set it to the first allowed origin
  const corsOrigin = normalizedAllowedOrigins.includes(normalizedRequestOrigin)
    ? requestOrigin  // Use the original request origin (with or without trailing slash)
    : (allowedOrigins[0] || '*');
  
  console.log(`===> Request origin: ${requestOrigin}, CORS origin: ${corsOrigin}`);
  
  const corsHeaders = {
    'Access-Control-Allow-Origin': corsOrigin,
    'Access-Control-Allow-Headers': 'Content-Type, Accept, SecureURL, PrivateKey, Token',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Content-Type': 'application/json',
  };

  // Handle OPTIONS (CORS preflight)
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({ message: 'CORS preflight successful' }),
    };
  }

  // 2. Read environment variables (or use hard-coded values)
  // Updated default store URL
  const storeUrl = process.env.SHIFT4SHOP_STORE_URL || 'http://311n16875921454.3dcartstores.com';
  const privateKey = process.env.SHIFT4SHOP_PRIVATE_KEY || '37ab4b76efdd4a63c967655b9d616610';
  const token = process.env.SHIFT4SHOP_TOKEN || '910d514950707115391650f15e36aa56';

  // 3. The merchant's secure URL – your store URL
  const secureUrl = '311n16875921454.s4shops.com';

  // 4. Validate required credentials
  if (!storeUrl || !privateKey || !token) {
    console.error('===> Missing one or more required environment variables.');
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({
        error: 'Missing SHIFT4SHOP_STORE_URL, SHIFT4SHOP_PRIVATE_KEY, or SHIFT4SHOP_TOKEN',
      }),
    };
  }

  // 5. Parse the path and method
  const path = event.path || '';
  const pathParameters = event.pathParameters || {};
  const httpMethod = event.httpMethod;
  let requestBody = null;
  
  // Extract endpoint path - based on your API Gateway setup
  let resourcePath = '';
  
  // If proxy path parameter is available, use it
  if (pathParameters.proxy) {
    resourcePath = `/${pathParameters.proxy}`;
  } 
  // Otherwise, extract from the path
  else if (path) {
    // Get the last segment of the path
    const pathParts = path.split('/').filter(Boolean);
    if (pathParts.length > 0) {
      resourcePath = `/${pathParts[pathParts.length - 1]}`;
    }
    
    // Handle case where we have an order ID
    if (pathParts.length > 1 && pathParts[pathParts.length - 2] === 'Orders') {
      resourcePath = `/Orders/${pathParts[pathParts.length - 1]}`;
    }
  }
  
  console.log('===> Resource path extracted:', resourcePath);
  
  // Handle query parameters
  let queryString = '';
  if (event.queryStringParameters) {
    const params = [];
    for (const [key, value] of Object.entries(event.queryStringParameters)) {
      params.push(`${encodeURIComponent(key)}=${encodeURIComponent(value)}`);
    }
    if (params.length > 0) {
      queryString = `?${params.join('&')}`;
    }
  }
  
  // Parse the request body if present
  if (event.body) {
    try {
      requestBody = JSON.parse(event.body);
    } catch (error) {
      console.error('===> Error parsing request body:', error);
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ error: 'Invalid request body' }),
      };
    }
  }
  
  // 6. Log the request details
  console.log(`===> Request details:
    Path: ${path}
    Resource Path: ${resourcePath}
    HTTP Method: ${httpMethod}
    Query String: ${queryString}`);
  
  // 7. Execute the appropriate API call based on the endpoint and method
  try {
    let response;
    // Build the complete API URL
    const apiUrl = `${storeUrl}/3dCartWebAPI/v1${resourcePath}${queryString}`;
    console.log(`===> Making ${httpMethod} request to: ${apiUrl}`);
    
    const headers = {
      PrivateKey: privateKey,
      Token: token,
      SecureURL: secureUrl,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    
    // Execute the appropriate HTTP method
    switch (httpMethod) {
      case 'GET':
        response = await axios.get(apiUrl, { headers, timeout: 10000 });
        break;
      case 'POST':
        // Mask sensitive data in logs
        if (requestBody && requestBody.CardNumber) {
          console.log('===> Order data:', JSON.stringify({
            ...requestBody,
            CardNumber: '****',
            CardVerification: '***'
          }).substring(0, 1000) + (JSON.stringify(requestBody).length > 1000 ? '...' : ''));
        } else {
          console.log('===> Request body:', JSON.stringify(requestBody).substring(0, 1000) + 
                      (JSON.stringify(requestBody).length > 1000 ? '...' : ''));
        }
        response = await axios.post(apiUrl, requestBody, { headers, timeout: 15000 });
        break;
      case 'PUT':
        console.log('===> Request body:', JSON.stringify(requestBody).substring(0, 1000) + 
                    (JSON.stringify(requestBody).length > 1000 ? '...' : ''));
        response = await axios.put(apiUrl, requestBody, { headers, timeout: 10000 });
        break;
      case 'DELETE':
        response = await axios.delete(apiUrl, { headers, timeout: 10000 });
        break;
      default:
        return {
          statusCode: 400,
          headers: corsHeaders,
          body: JSON.stringify({ error: `Unsupported HTTP method: ${httpMethod}` }),
        };
    }
    
    console.log(`===> API response status: ${response.status}`);
    
    // Log a sample of the response data
    if (response.data) {
      const dataStr = JSON.stringify(response.data);
      console.log(`===> API response data sample:`, dataStr.substring(0, 500) + (dataStr.length > 500 ? '...' : ''));
    }
    
    // For certain endpoints, provide fallback data if response is empty
    if (httpMethod === 'GET') {
      if (resourcePath.includes('/products') && (!response.data || response.data.length === 0)) {
        console.log('===> No products returned, using fallback products');
        return {
          statusCode: 200,
          headers: corsHeaders,
          body: JSON.stringify(fallbackProducts),
        };
      }
      
      if (resourcePath.includes('/OrderStatus') && (!response.data || response.data.length === 0)) {
        console.log('===> No order statuses returned, using fallback statuses');
        return {
          statusCode: 200,
          headers: corsHeaders,
          body: JSON.stringify(fallbackOrderStatuses),
        };
      }
    }
    
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify(response.data),
    };
    
  } catch (error) {
    console.error(`===> API request error: ${error.message}`);
    
    if (error.response) {
      console.error('===> Error response status:', error.response.status);
      console.error('===> Error response data:', error.response.data);
    }
    
    // For specific endpoints, return fallback data on error
    if (httpMethod === 'GET') {
      if (resourcePath.includes('/products')) {
        console.log('===> Error fetching products, using fallback data');
        return {
          statusCode: 200,
          headers: corsHeaders,
          body: JSON.stringify(fallbackProducts),
        };
      }
      
      if (resourcePath.includes('/OrderStatus')) {
        console.log('===> Error fetching order statuses, using fallback data');
        return {
          statusCode: 200,
          headers: corsHeaders,
          body: JSON.stringify(fallbackOrderStatuses),
        };
      }
    }
    
    // General error response
    return {
      statusCode: error.response?.status || 500,
      headers: corsHeaders,
      body: JSON.stringify({
        error: error.response?.data || error.message,
        message: `Failed to process ${httpMethod} request to ${resourcePath}`
      }),
    };
  }
};