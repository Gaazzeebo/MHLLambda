// index.mjs (ES module format)
import axios from 'axios';

// Optional fallback data if the API call fails
const fallbackProducts = [
  {
    catalogid: 999,
    name: 'Fallback Product',
    price: 9.99,
    thumbnailurl: '/assets/logo-placeholder.png',
    mainimagefile: '/assets/logo-placeholder.png',
    description: 'Returned if the legacy API call fails.',
    stock: 99,
    featured: false,
    categoryid: 'shift4shop',
  },
];

export const handler = async (event) => {
  console.log('===> Event received:', JSON.stringify(event));

  // 1) CORS Handling
  const origin = event.headers?.origin || '*';
  const corsHeaders = {
    'Access-Control-Allow-Origin': origin,
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET,OPTIONS',
    'Content-Type': 'application/json',
  };

  // CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({ message: 'CORS preflight successful' }),
    };
  }

  // 2) Load environment variables
  // storeUrl should NOT include /3dCartWebAPI/v2/ in it (just the domain)
  const storeUrl = process.env.SHIFT4SHOP_STORE_URL || '';
  const privateKey = process.env.SHIFT4SHOP_PRIVATE_KEY || '';
  const token = process.env.SHIFT4SHOP_TOKEN || '';

  // 3) Validate credentials
  if (!storeUrl) {
    console.error('===> Missing SHIFT4SHOP_STORE_URL');
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ error: 'Missing SHIFT4SHOP_STORE_URL env var' }),
    };
  }
  if (!privateKey) {
    console.error('===> Missing SHIFT4SHOP_PRIVATE_KEY');
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ error: 'Missing SHIFT4SHOP_PRIVATE_KEY env var' }),
    };
  }
  if (!token) {
    console.error('===> Missing SHIFT4SHOP_TOKEN');
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ error: 'Missing SHIFT4SHOP_TOKEN env var' }),
    };
  }

  // 4) Build the final v2 endpoint
  // Example:
  // storeUrl = "https://311n16875921454.3dcartstores.com"
  // final => "https://311n16875921454.3dcartstores.com/3dCartWebAPI/v2/Products?limit=100"
  const apiUrl = `${storeUrl}/3dCartWebAPI/v2/Products?limit=100`;

  console.log(`===> Attempting to fetch products from: ${apiUrl}`);

  try {
    // 5) Make the request with PrivateKey & Token
    const response = await axios.get(apiUrl, {
      headers: {
        PrivateKey: privateKey,
        Token: token,
        Accept: 'application/json',
        'Content-Type': 'application/json',
        // SecureURL: storeUrl, // Some stores also need this
      },
      timeout: 10000, // 10s
    });

    console.log('===> SHIFT4SHOP v2 API response status:', response.status);
    console.log('===> SHIFT4SHOP v2 data length:', response.data?.length);

    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify(response.data),
    };
  } catch (error) {
    console.error('===> SHIFT4SHOP v2 API fetch error:', error.message);
    if (error.response) {
      console.error('===> Error response data:', error.response.data);
      console.error('===> Error response status:', error.response.status);
    }

    // 6) Fallback to local array so your code still returns something
    console.log('===> Falling back to local fallbackProducts array...');
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify(fallbackProducts),
    };
  }
};
