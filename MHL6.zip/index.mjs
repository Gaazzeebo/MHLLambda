// index.mjs
import axios from 'axios';

// Optional fallback data (returned if your API call fails).
// Replace or remove this as you see fit.
const fallbackProducts = [
  {
    catalogid: 999,
    name: 'Fallback Product',
    price: 9.99,
    thumbnailurl: '/assets/logo-placeholder.png',
    mainimagefile: '/assets/logo-placeholder.png',
    description: 'This product is returned if the Shift4Shop v2 API call fails.',
    stock: 99,
    featured: false,
    categoryid: 'shift4shop',
  },
];

/**
 * AWS Lambda Handler
 * 
 * Expects a GET request (and handles OPTIONS for CORS).
 * Calls the Shift4Shop (3dcart) v2 API with PrivateKey + Token.
 */
export const handler = async (event) => {
  console.log('===> Event received:', JSON.stringify(event));

  // 1) CORS Setup
  const origin = event.headers?.origin || '*';
  const corsHeaders = {
    'Access-Control-Allow-Origin': origin,
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET,OPTIONS',
    'Content-Type': 'application/json',
  };

  // Handle CORS preflight request
  if (event.httpMethod === 'OPTIONS') {
    console.log('===> Handling CORS preflight');
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({ message: 'CORS preflight successful' }),
    };
  }

  // 2) Read environment variables from AWS Lambda configuration
  //    or you can hard-code them if absolutely necessary (less secure).
  const storeUrl = process.env.SHIFT4SHOP_STORE_URL || 'https://apirest.3dcart.com';
  const privateKey = process.env.SHIFT4SHOP_PRIVATE_KEY || '';
  const token = process.env.SHIFT4SHOP_TOKEN || '';

  // 3) Validate we have all credentials
  if (!storeUrl) {
    console.error('===> Missing SHIFT4SHOP_STORE_URL');
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ error: 'Missing SHIFT4SHOP_STORE_URL environment variable' }),
    };
  }

  if (!privateKey) {
    console.error('===> Missing SHIFT4SHOP_PRIVATE_KEY');
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ error: 'Missing SHIFT4SHOP_PRIVATE_KEY environment variable' }),
    };
  }

  if (!token) {
    console.error('===> Missing SHIFT4SHOP_TOKEN');
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ error: 'Missing SHIFT4SHOP_TOKEN environment variable' }),
    };
  }

  // 4) Construct the v2 endpoint
  //    apirest.3dcart.com is commonly used for older 3dcart-based stores,
  //    including passing your PrivateKey & Token in headers.
  //    Adjust the path or version if your store uses /v1 instead of /v2, etc.
  const apiUrl = `${storeUrl}/3dCartWebAPI/v2/Products?limit=100`;

  console.log(`===> Attempting to fetch products from: ${apiUrl}`);

  try {
    const response = await axios.get(apiUrl, {
      headers: {
        PrivateKey: privateKey,
        Token: token,
        Accept: 'application/json',
        'Content-Type': 'application/json',
        // Sometimes stores also require:
        // SecureURL: storeUrl,
      },
      timeout: 10000, // 10 seconds
    });

    console.log('===> SHIFT4SHOP v2 API response status:', response.status);
    console.log('===> SHIFT4SHOP v2 API response data length:', response.data?.length);

    // Return product data as JSON
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify(response.data),
    };

  } catch (error) {
    console.error('===> SHIFT4SHOP v2 API fetch error:', error.message);

    if (error.response) {
      // Log the response data for debugging (HTML for 404, JSON for 400/500, etc.)
      console.error('===> Error response data:', error.response.data);
      console.error('===> Error response status:', error.response.status);
    }

    // If we want to fallback to some local or static data:
    console.log('===> Falling back to local fallbackProducts array...');
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify(fallbackProducts),
    };
  }
};
